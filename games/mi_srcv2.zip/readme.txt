Updated 12/25/03
 _____________________________
|                             \
| MADNESS INTERACTIVE README   \
|_______________________________\

1. About
2. New features in the executable version
3. Controls
4. Stats
5. FAQs
6. Cheats

 ____________
|            \
| 1 - About   \
|______________\

Madness Interactive is a side-view shooter produced in Flash 5 and MX.  The executable version was created with the aid of
SWF Studio, which I was able to purchase thanks to the generous contributions of visitors to Flecko.net.

     Art: KRINKELS [krinkels@juno.com]
 Program: MAX ABERNETHY [http://www.flecko.net] [max_abernethy@hotmail.com]
   Music: MMODULE [http://www.mmodule.com]
    Fire: KOMANI [http://www.liquid-fires.com]

Flecko.net is not yet self-sufficient.  We are selling T-shirts to pay for hosting.  If you want to help fund us but don't 
want to spend $20 on a shirt, we also accept donations.

You may redistribute this game as long as it is completely intact.  The source code is available on flecko.net, as well as a 
guide to making mods.

 _______________
|               \
| 2 - Features   \
|_________________\_____________
|New to this version (12/25/03) |
+-------------------------------+

-The main game has been changed. There are now limited lives, and at the end of each scene you get to choose a powerup that lasts 
 for the rest of the game.

-The middle-mouse button throws away your weapon.

-You can alternate weapons by spinning the mouse wheel.

-The mouse problems are completely fixed and gone forever. -Forever-.

-Some of the guns now have animated slides: Beretta, Uzi, DE, Silenced pistol, and Automag.

-Some graphics have been changed.

-The mouse repeat rate has been increased. I strongly suggest you get used to shooting all guns just by holding the
 mouse button down.

-Guns with limited fire rates (Shotgun, M79, and Railgun) now recover even when they're holstered. If you have two shotguns, you
 can alternate between them and fire at double the rate you otherwise would.

-The M16 and M60 can be thrown now, only half as far as any of the other guns.

-Guns are now inaccurate. The first shot you fire will be perfectly accurate, but after that your aim will degrade further with 
 each shot you fire. Even when you aren't shooting, it takes some time to recover your aim.

-Shells no longer stay on screen between scenes.

-The UMP45 (Numpad 4) now only holds 25 bullets.

-You can no longer detonate a suicide bomb while invincible at the beginning of a life (while flashing).

+------------------------+
|New to the last version |
+------------------------+

-The right-mouse button can now toggle bullet-time.  There is no context menu anymore, so that is its only effect.  The mouse 
 button cannot be assigned to any other task, but you can still change the key.

-There is a new fullscreen mode (Options>Display>Toggle Fullscreen).  There were ways of playing the game in fullscreen before
 by scaling the Flash window, but that decreased performance.  This mode changes your screen resolution to accomodate the game,
 so it can take up your whole screen without slowing down.

-You can now save your preferences!  Everything setting in the options menu can be saved, and will automatically be loaded each 
 time the game starts up.  To save any changes you've made in the options panel, click on Options>Save Preferences.  This will 
 record your key mapping, your quality and detail mode, music on/off setting, fullscreen, and costume.

 _______________
|               \
| 3 - Controls   \
|_________________\

The default key mapping:

  Move hand: Mouse
      Shoot: Left mouse button
         Up: W
       Left: A
       Down: S
      Right: D
Bullet-time: Q or Right mouse button
 Switch gun: E or Mouse wheel
   Drop gun: F or Middle mouse button
      Pause: P
 Go to menu: Enter/Return
  Quit game: Esc

 ____________
|            \
| 4 - Stats   \
|______________\

All the info you ever needed about hitpoints and damage.

HITPOINTS

     Human player: 10
       Regular AI: 3
           Zombie: 3, but takes 1/4 damage while Jesus is onscreen
 Jesus (maingame): 175
Jesus (challenge): 25


GUN DAMAGE (Guns are listed in their order on the keyboard in experiment mode)

   Pistol: 1
  Shotgun: 1 x 5
      Uzi: 1 x 3
      M16: 2
      CQB: .75
       DE: 2
      M60: 2 x 3
      SMG: .75
S. Pistol: 1
    AK-47: 2
    Saiga: 1 x 5
Steyr Aug: 1.5
      L85: 1.25
      UMP: 2
  Minigun: 2
  Railgun: 3 x enemies hit
      RPG: 10 on contact + explosion damage
 Flamegun: 9/flame/sec
  Automag: 3
    Tazer: 0
       GL: 10 on contact + explosion damage

MELEE DAMAGE

Default damage: 1 to 1.5, depending on strength
       Bonuses: With anything but hand - x1.5
                           From behind - x3
                            With blade - +1 to 1.5, depending on strength
                           With urinal - x2 with flat +2 damage bonus


 ___________
|           \
| 5 - FAQs   \
|_____________\

After the first time I said, "I'd like to hear what you think," it didn't take too long for me to figure 
out what a horrible mistake I'd made.  Now, the sort of people who fill my inbox with drivel probably 
can't focus long enough to read an FAQ (Note to self: stop making twitch games), but in hopes of avoiding 
these problems, I have READ YOUR MINDS (actually, the hundreds of questions I've been asked over and over 
by people too lazy to scan recent forum topics before posting) and produced this list.

Q: Hey, want to hear my game idea/idea for your game?
A: NO.

Q: Sure?  Cause it's really c--
A: NO.

Q: Is there going to be another Madness game?
A: I haven't ruled out the possibility of a content update, but I have no plans to make another full game.
   That's not to say that somebody else won't do it.  The source code is available on flecko.net, so 
   others can modify it if they please.  I must warn about that, though - the game was poorly planned, so 
   the code is not very well organized, seldom explicit, and even more seldom commented.  (Some of the 
   comments are probably lies, even).

Q: How did you learn to program?
A: I read a book or two, spent plenty of time looking at source code on Flashkit and reading the forums, 
   and pushed all the buttons.  That's important - the best way to learn is to just try everything and 
   see what it is.

Q: I'm an artist/programmer/whatever.  Will you make a game with me?
A: I'm not entirely sure what my next project will be yet, or how I will go about making it.  At some 
   point in the near future, though, I will definitely be in need of at least one artist, and possibly 
   an assistant programmer as well.  I will post information on Flecko.net when the time comes, but 
   if you've already got a lot of work you would like to show me, I would be glad to take a look at 
   it and hold on to your contact info.

   I should note that the next game will not be made in Flash, so skill in that particular discipline 
   doesn't make a difference.  But you can still show me work in Flash if it reflects your artistic 
   skill.

Q: What was that anime you were talking about earlier?
   Fooly Cooly (FLCL). Ask anyone, I won't shut up about it.


 _____________
|             \
| 6 - CHEATS   \
|_______________\

WARNING - If you want the satisfaction of earning these for yourself, read no further! 
The cheats are essentially just a bunch of fun little mods to the game.  You can't 
earn more cheats while cheats are active, or get rated by the main game.

       Willis: invincibility
NewYorkMinute: Infinite bullet-time
        Guide: Aiming line
    Armstrong: 2x Reach (IMO, this one's the coolest)
       Apollo: All enemies use explosives
         FLCL: Infinite ammo (Hey, who here can guess what anime I have an unhealthy obsession with?)
          Hop: Higher jump
         Gump: 2x Speed (Try this in combination with infinite bullet-time!)
       Minnie: Spawn with minigun
       Arnold: 4x strength 


