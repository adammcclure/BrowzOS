default controls.

a - left
d - right
w - jump (can jump once in mid-air)
e - switch weapons
f - throw weapon
q - slow motion

mouse - move hand
left click - shoot, pick up weapon
right click - slow motion

move hand over a weapon and click to pick it up.
hit enemies by swinging your hand at them.
throw stuff by pressing 'f' while swinging your hand.